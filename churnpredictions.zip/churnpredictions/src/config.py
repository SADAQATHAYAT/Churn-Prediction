
DATA_PATH = "data/customer_churn.csv"
ARTIFACTS_PATH = "artifacts"
RANDOM_STATE = 42
TEST_SIZE = 0.2
TARGET_COLUMN = "Churn"
